## Quick Image Saver

A lightweight Firefox extension that allows quick and easy way to save images. 

## Manual Installation (Development)
Requires [Node Package Manager](https://nodejs.org/en)
```
git clone https://github.com/T-Gomziakov/Quick-Image-Saver.git
cd Quick-Image-Saver
npm install
npm run build
cd ./dist
web-ext run
```
